import {apiResponse} from './data.js';

$(document).ready( function () {
    $('#myTable').DataTable();
} );

var k = '<tbody>'
for(let i = 0;i < apiResponse.length; i++){
    k+= '<tr>';
    k+= '<td>' + apiResponse[i].name + '</td>';
    k+= '<td>' + apiResponse[i].age + '</td>';
    k+= '<td>' + apiResponse[i].healthy + '</td>';
    k+= '<td>' + apiResponse[i].location + '</td>';
    k+= '<td>' + apiResponse[i].vol_name + '</td>';
    k+= '<td>' + apiResponse[i].voul_no + '</td>';
    k+= '</tr>';
}
k+='</tbody>';
document.getElementById('tableData').innerHTML = k;