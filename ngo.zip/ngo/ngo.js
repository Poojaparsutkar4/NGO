export const apiResponse = [
    {
       
        lat:29.2183,
        long:79.5130
    },
    {
        
        lat:15.2993,
        long:74.1240
    },
    {
        
        lat:28.3670,
        long:79.4304
    },
    {
        
        lat:30.3165,
        long:78.0322
    },
    {
        
        lat:30.3165,
        long:78.0322
    },
    {
        
        lat:29.2183,
        long:79.5130
    },
    {
        
        voul_no:9797122543,
        lat:19.0760,
        long:72.8777
    },
    {
        
        lat:30.7333,
        long:76.7794
    },
    {
        
        voul_no:9117122543,
        lat:29.2183,
        long:79.5130
    },
   
];
