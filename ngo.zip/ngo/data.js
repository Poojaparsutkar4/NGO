export const apiResponse = [
    {
        name: "Kapil",
        age:  11,
        healthy: 'not healthy',
        location: 'Haldwani Bus Stand',
        vol_name: 'Gopal',
        voul_no:9997122543,
        lat:29.2183,
        long:79.5130
    },
    {
        name: "Gopal",
        age:  8,
        healthy: 'healthy',
        location: 'Goa',
        vol_name: 'Tushar',
        voul_no:999122543,
        lat:15.2993,
        long:74.1240
    },
    {
        name: "Ramesh",
        age:  5,
        healthy: 'not healthy',
        location: 'Bareilly Bus stand',
        vol_name: 'Ram',
        voul_no:999022543,
        lat:28.3670,
        long:79.4304
    },
    {
        name: "Suresh",
        age:  16,
        healthy: 'healthy',
        location: 'Dehradun near upes college',
        vol_name: 'Pranjal',
        voul_no:9097122543,
        lat:30.3165,
        long:78.0322
    },
    {
        name: "Radha",
        age:  6,
        healthy: 'not healthy',
        location: 'Dehradun near isbt',
        vol_name: 'Ritvik',
        voul_no:9897122543,
        lat:30.3165,
        long:78.0322
    },
    {
        name: "Kapil",
        age:  17,
        healthy: 'not healthy',
        location: 'Mukhani Haldwani',
        vol_name: 'Surendar',
        voul_no:9197122543,
        lat:29.2183,
        long:79.5130
    },
    {
        name: "Lokesh",
        age:  11,
        healthy: 'healthy',
        location: 'Mumbai',
        vol_name: 'Harshit',
        voul_no:9797122543,
        lat:19.0760,
        long:72.8777
    },
    {
        name: "Durgesh",
        age:  13,
        healthy: 'not healthy',
        location: 'Chandigarh IT Park',
        vol_name: 'Mukul',
        voul_no:897122543,
        lat:30.7333,
        long:76.7794
    },
    {
        name: "Shubham",
        age:  4,
        healthy: 'not healthy',
        location: 'Unchapul Haldwani',
        vol_name: 'Shyam',
        voul_no:9117122543,
        lat:29.2183,
        long:79.5130
    },
    {
        name: "Rekha",
        age:  11,
        healthy: 'healthy',
        location: 'Haldwani Bus Stand',
        vol_name: 'Gopal',
        voul_no:9997122543,
        lat:29.2183,
        long:79.5130
    },
    {
        name: "Jaya",
        age:  10,
        healthy: 'healthy',
        location: 'Haldwani Bus Stand',
        vol_name: 'Gopal',
        voul_no:9997122543,
        lat:29.2183,
        long:79.5130
    },
    {
        name: "Vimla",
        age:  5,
        healthy: 'not healthy',
        location: 'Pilikoti Haldwani',
        vol_name: 'Khagendra',
        voul_no:9997122533,
        lat:29.2183,
        long:79.5130
    },
    {
        name: "Pooja",
        age:  5,
        healthy: 'not healthy',
        location: 'Pilikoti Haldwani',
        vol_name: 'Khagendra',
        voul_no:9997122533,
        lat:29.2183,
        long:79.5130
    }
];
