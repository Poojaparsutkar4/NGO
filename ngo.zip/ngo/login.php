<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>HELPZ - Free Charity Website Template</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Free Website Template" name="keywords">
        <meta content="Free Website Template" name="description">

        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        
        <!-- CSS Libraries -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>
       <!-- Top Bar Start -->
       <div class="top-bar d-none d-md-block">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-8">
                    <div class="top-bar-left">
                        <div class="text">
                            <i class=Phone no></i>
                            <p>9921995190</p>
                        </div>
                        <div class="text">
                            <i class="fa fa-envelope"></i>
                            <p>Parsutkarpooja@gmail.com</p>
                            <p>divyanshikesarwani12@gmail.com</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="top-bar-right">
                        <div class="social">
                            <a href=""><i class="fab fa-twitter"></i></a>
                            <a href=""><i class="fab fa-facebook-f"></i></a>
                            <a href=""><i class="fab fa-linkedin-in"></i></a>
                            <a href=""><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Top Bar End -->

        <!-- Nav Bar Start -->
        <div class="navbar navbar-expand-lg bg-dark navbar-dark">
            <div class="container-fluid">
                <a href="index.html" class="navbar-brand">Helpz</a>
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                    <div class="navbar-nav ml-auto">
                        <a href="index.html" class="nav-item nav-link active">Home</a>
                        <a href="child.html" class="nav-item nav-link">Register Child </a>
                        <a href="Vol.html" class="nav-item nav-link">Volunteer login</a>
                        <a href="listView.html" class="nav-item nav-link">Child details</a>
                        <a href="mapView.html" class="nav-item nav-link">Ngo Location</a>
                        
                        
                        <a href="contact.html" class="nav-item nav-link">Contact</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Nav Bar End -->
        
        
        <!-- Page Header Start -->
        <div class="page-header">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h2>Contact Us</h2>
                    </div>
                    <div class="col-12">
                        <a href="">Home</a>
                        <a href="">Contact</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page Header End -->
        
        
        <!-- Contact Start -->
        <div class="contact">
            <div class="container">
                <div class="section-header text-center">
                    <p>Get In Touch</p>
                    <h2>Contact for any query</h2>
                </div>
                <div class="contact-img">
                    <img src="img/contact.jpg" alt="Image">
                </div>
                <div class="contact-form">
                        <div id="success"></div>
                        <form name="sentMessage" id="contactForm" novalidate="novalidate">
                            <div class="control-group">
                                <input type="text" class="form-control" id="fname" placeholder="Enter Your Name" required="required" data-validation-required-message="Please enter your name" />
                                <p class="help-block text-danger"></p>
                            </div>
                            <div class="control-group">
                                <input type="email" class="form-control" id="phone" placeholder="Enter Your Phone no" required="required" data-validation-required-message="Please enter your Phone number" />
                                <p class="help-block text-danger"></p>
                            </div>
                            <div class="control-group">
                                <input type="text" class="form-control" id="Age" placeholder="Enter the Child Age" required="required" data-validation-required-message="Please enter your Chile Age" />
                                <p class="help-block text-danger"></p>
                            </div>
                            <div class="control-group">
                                <textarea class="form-control" id="Child Name" placeholder="Enter  child name" required="required" data-validation-required-message="Please enter your Child name"></textarea>
                                <p class="help-block text-danger"></p>
                            </div>
                            <div class="control-group">
                                <textarea class="form-control" id="Healthiness" placeholder="Enter your Health State" required="required" data-validation-required-message="Please enter your Health State"></textarea>
                                <p class="help-block text-danger"></p>
                            </div>
                            <div class="control-group">
                                <textarea class="form-control" id="Gender" placeholder="Enter child gender" required="required" data-validation-required-message="Please enter the child gender"></textarea>
                                <p class="help-block text-danger"></p>
                            </div>
                            <div class="control-group">
                                <textarea class="form-control" id="Adresss" placeholder="Enter your Adress" required="required" data-validation-required-message="Please enter your address"></textarea>
                                <p class="help-block text-danger"></p>
                            </div>
                            <div>
                                <button class="btn btn-custom" type="submit" id="sendMessageButton">Send Message</button>
                            </div>
                        </form>
                    </div>
            </div>
        </div>
        <!-- Contact End -->


                <!-- Footer Start -->
                <div class="footer">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-3 col-md-6">
                                <div class="footer-contact">
                                    <h2>Our Head Office</h2>
                                    <p><i class="fa fa-map-marker-alt"></i>Kelambbkum, Chennai, India</p>
                                    <p><i class="fa fa-phone-alt"></i>9834498125</p>
                                    <p><i class="fa fa-envelope"></i>divyanshikesarwani12@gmail.com</p>
                                    <div class="footer-social">
                                        <a class="btn btn-custom" href=""><i class="fab fa-twitter"></i></a>
                                        <a class="btn btn-custom" href=""><i class="fab fa-facebook-f"></i></a>
                                        <a class="btn btn-custom" href=""><i class="fab fa-youtube"></i></a>
                                        <a class="btn btn-custom" href=""><i class="fab fa-instagram"></i></a>
                                        <a class="btn btn-custom" href=""><i class="fab fa-linkedin-in"></i></a>
                                    </div>
                                </div>
                            </div>
                            
                            
                            <div class="col-lg-3 col-md-6">
                                <div class="footer-newsletter">
                                    
                                    <form>
                                        <input class="form-control" placeholder="Email goes here">
                                        <button class="btn btn-custom">Submit</button>
                                        <label>Don't worry, we don't spam!</label>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="container copyright">
                        <div class="row">
                            <div class="col-md-6">
                                <p>&copy; <a href="#">Helping Hands</a>, All Right Reserved.</p>
                            </div>
                            <div class="col-md-6">
                                <p>Designed By <a href="https://htmlcodex.com">Pooja and Divyanshi</a></p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Footer End -->

        <!-- Back to top button -->
        <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
        
        <!-- Pre Loader -->
        <div id="loader" class="show">
            <div class="loader"></div>
        </div>

        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>
        <script src="lib/waypoints/waypoints.min.js"></script>
        <script src="lib/counterup/counterup.min.js"></script>
        <script src="lib/parallax/parallax.min.js"></script>
        
        <!-- Contact Javascript File -->
        <script src="mail/jqBootstrapValidation.min.js"></script>
        <script src="mail/contact.js"></script>

        <!-- Template Javascript -->
        <script src="js/main.js"></script>
    </body>
</html>


<form method="post" action="child.php" >
    <p><input type="text" placeholder="User name" name="fname" required></p>
	<p><input type="tel" id="phone" name="phone"  placeholder="User Phone Number" required></p>
	<p><input type="text" placeholder="Child name(If known)" name="name"></p>
	
	<p><input type="text" placeholder="Healthiness" name="condition"></p>
	<p><input type="text" placeholder="Age" name="age"></p>
	<p><input type="text" placeholder="Gender" name="gender"></p>
	<p><textarea id="Address" name="Address" rows="4" cols="45" placeholder="Address" name= "address" required></textarea></p>
    <p><input type="submit" value="Submit"></p>
	<p><input type="reset" value="Reset"></p>
  </form>